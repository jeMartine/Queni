public class Automata {
    char estado;
    public boolean validarCorreo(String correo){
        char[] letras = correo.toCharArray();
        for(char c: letras){
            if(verificarLetras(c)==false){
                return false;
            }
        }
        return true;
    }

    public boolean verificarLetras(char letra){
        boolean esMayuscula=false, esMinuscula=false;
        for(int i=65; i<=90; i++){
            if(letra == i){
                esMayuscula=true;
            }
        }
        for(int i=97; i<=122; i++){
            if(letra == i){
                esMinuscula=true;
            }
        }
        if(esMayuscula || esMinuscula){
            return true;
        } else{
            return false;
        }
    }
}
