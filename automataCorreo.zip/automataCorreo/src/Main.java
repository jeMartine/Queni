public class Main {
    public static void main(String[] args) {
        Automata a = new Automata();

    }
}